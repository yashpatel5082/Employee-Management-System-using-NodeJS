const express = require('express');
const path = require('path');
const ejs = require('ejs');
const bodyParser = require('body-parser')
const mongoose = require('mongoose');

const bcrypt = require('bcrypt');
const session = require("express-session");
mongoose.connect('mongodb+srv://admin:admin@cluster0.dfudem0.mongodb.net/assignment3', { useNewUrlParser: true })

const User = require('./model/userProfile');

const app = new express();

app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.static(path.join(__dirname, "public")));


app.use(session({
  secret: "YASHVAGHASIYA", resave: true,
  saveUninitialized: true
}));

global.loggedIn = null;
global.usertype = null;

app.use("*", (req, res, next) => {
  loggedIn = req.session.userId;
  usertype = req.session.UserType;
  next();
})

app.get("/", (req, res) => {
  res.render("Dashboard");
});

app.get("/LOGIN", (req, res) => {
  res.render("LOGIN");
});

app.get("/G_PAGE", async (req, res) => {
  const getuser = await User.findById(req.session.userId);

  res.render('G_display', { user: [getuser] });
});

app.get("/G2_PAGE", (req, res) => {
  res.render("G2_PAGE");
});

app.post("/saveinfo", (req, res) => {

  const data = req.body;
  User.findByIdAndUpdate(req.session.userId, data, (error, sucess) => {

    res.redirect("G_PAGE");
  })

});
app.post("/login", (req, res) => {
  const body = req.body;

  const { username, password } = req.body;
  User.findOne({ username: username }, (error, user) => {
    if (user) {
      bcrypt.compare(password, user.password, (error, same) => {
        if (same) {

          req.session.userId = user._id;
          req.session.UserType = user.usertype;
          res.redirect("/");
        }
        else {
          res.redirect('/login');
        }
      })
    }
    else {
res.redirect('/login');
    }
  })

}
)

app.post("/register", (req, res) => {
  const body = req.body;

  const user = {
    firstname: "YASH",
    licenseno: 223344,
    lastname: "VAGHASIYA",
    age: 19,
    username: body.username,
    password: body.password,
    usertype: body.usertype,

    makeIE: "MakeIE",
    model: "model",
    year: new Date().getFullYear(),
    platenumber: "platenumber"
  }

  bcrypt.hash(user.password, 10, (error, hash) => {
    user.password = hash;
    User.create(user, (error, sucess) => {
      console.log("saved", error, user)
      res.render('Dashboard');
    })
  })

}
)
app.get("/update", (req, res) => {

  User.findOneAndUpdate({ licenseno: req.query.licenseno },
    {
      platenumber: req.query.platenumber, makeIE: req.query.makeIE,
      model: req.query.model, year: req.query.year
    }, (error, user) => {
      console.log(error, user)
      res.redirect("G_PAGE")
    });
})
app.get("/information", async (req, res) => {
  const data = req.query;
  const getuser = await User.findById(req.session.userId);

  res.render('display', { user: getuser });
})


app.listen(3000, () => {
  console.log("App listening on port 3000");
});

