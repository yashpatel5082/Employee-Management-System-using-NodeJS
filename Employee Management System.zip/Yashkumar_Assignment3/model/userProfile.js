const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const Model = new Schema({
    fname: { type: String },
    license: { type: Number },
    lname: { type: String },
    age: { type: Number },
    username:String,
    password:String,
    usertype:String,
    DOB:Date,
    
    makeie:{ type: String },
    model: { type: String },
    year: { type: Number },
    plateno: { type: String }
    
});

const User = mongoose.model("User", Model);
module.exports = User;

